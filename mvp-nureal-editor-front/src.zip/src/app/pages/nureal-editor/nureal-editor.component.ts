import { Component, OnInit } from '@angular/core';
import { Application } from '../../core/interfaces/application.interface';
import { PageComponent } from '../../core/interfaces/pageComponent.interface';

import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-nureal-editor',
  standalone: true,
  imports: [
    CommonModule,
    FormsModule
  ],
  templateUrl: './nureal-editor.component.html',
  styleUrls: ['./nureal-editor.component.css']
})
export class NurealEditorComponent implements OnInit {

  selectedComponent: PageComponent | null = null;

  application: Application = {
    id: 1,
    name: 'Minha Aplicação',
    description: '',
    status: 'ATIVO',

    dateCreation: new Date(),
    dateAlteration: new Date(),
    userCreation: 'admin',
    userAlteration: 'admin',

    user: {
      id: 1,
      name: 'Admin',
      dateCreation: new Date(),
      dateAlteration: new Date(),
      userCreation: 'admin',
      userAlteration: 'admin',
    },

    pages: [
      {
        id: 1,
        name: 'Home',
        description: 'Página Inicial',

        pageComponents: [],

        dateCreation: new Date(),
        dateAlteration: new Date(),
        userCreation: 'admin',
        userAlteration: 'admin',
      },
    ],
  };

  constructor() {}

  ngOnInit(): void {}

  addText(): void {
    this.application.pages[0].pageComponents.push({
      id: Date.now().toString(),
      type: 'TEXT',
      order: this.application.pages[0].pageComponents.length + 1,

      config: {
        content: 'Novo Texto',
      },
    });
  }

  selectComponent(component: PageComponent): void {
    this.selectedComponent = component;
  }

}
