import { User } from './user.interface';
import { Page } from './page.interface';

export interface Application {
  id: number;
  name: string;
  description: string;
  status: 'ATIVO' | 'INATIVO';

  //
  // auditoria e controle
  //
  dateCreation: Date;
  dateAlteration: Date;
  userCreation: string;
  userAlteration: string;

  user: User;

  pages: Page[];
}
