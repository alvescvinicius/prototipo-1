import { PageComponent } from './pageComponent.interface';

export interface Page {
  id: number;
  name: string;
  description: string;

  pageComponents: PageComponent[];

  dateCreation: Date;
  dateAlteration: Date;
  userCreation: string;
  userAlteration: string;
}
