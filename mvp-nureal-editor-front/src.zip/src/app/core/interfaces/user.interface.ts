export interface User {
  id: number;
  name: string;

  //
  // auditoria e controle
  //
  dateCreation: Date;
  dateAlteration: Date;
  userCreation: string;
  userAlteration: string;
}
