export interface PageComponent {
  id: string;
  type: string;
  order: number;

  config: {
    content?: string;
  };
}
