import { Routes } from '@angular/router';

import { CadastroComponent } from './pages/cadastro/cadastro.component';
import { NurealEditorComponent } from './pages/nureal-editor/nureal-editor.component';

export const routes: Routes = [
  {
    path: '',
    component: NurealEditorComponent
  },
  {
    path: 'cadastro',
    component: CadastroComponent
  },
];
